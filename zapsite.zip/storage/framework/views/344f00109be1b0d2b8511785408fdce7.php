

<?php $__env->startSection('title', 'Stock Report - Zap Store'); ?>
<?php $__env->startSection('header', 'Stock Report'); ?>

<?php $__env->startSection('header-buttons'); ?>
<div class="flex space-x-4">
    <button onclick="window.print()" class="btn-primary text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
        <i class="fa fa-print"></i> Print Report
    </button>
    <a href="<?php echo e(route('reports.index')); ?>" class="bg-gray-500 text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
        <i class="fa fa-arrow-left"></i> Back to Reports
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-lg rounded-lg p-6">
    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div class="bg-blue-50 p-4 rounded-lg">
            <h3 class="text-lg font-semibold text-blue-700">Total Products</h3>
            <p class="text-3xl font-bold text-blue-800"><?php echo e($products->count()); ?></p>
        </div>
        <div class="bg-yellow-50 p-4 rounded-lg">
            <h3 class="text-lg font-semibold text-yellow-700">Low Stock Items</h3>
            <p class="text-3xl font-bold text-yellow-800">
                <?php echo e($products->where('stock', '<=', 10)->where('stock', '>', 0)->count()); ?>

            </p>
        </div>
        <div class="bg-red-50 p-4 rounded-lg">
            <h3 class="text-lg font-semibold text-red-700">Out of Stock</h3>
            <p class="text-3xl font-bold text-red-800">
                <?php echo e($products->where('stock', '<=', 0)->count()); ?>

            </p>
        </div>
    </div>

    <!-- Stock Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-50">
                <tr>
                    <th class="p-4">Product</th>
                    <th class="p-4">Code</th>
                    <th class="p-4">Category</th>
                    <th class="p-4">Current Stock</th>
                    <th class="p-4">Purchased</th>
                    <th class="p-4">Sold</th>
                    <th class="p-4">Status</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-4">
                        <div class="flex items-center">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" 
                                     alt="<?php echo e($product->name); ?>"
                                     class="w-10 h-10 rounded-lg object-cover mr-3">
                            <?php endif; ?>
                            <?php echo e($product->name); ?>

                        </div>
                    </td>
                    <td class="p-4"><?php echo e($product->code); ?></td>
                    <td class="p-4"><?php echo e($product->category); ?></td>
                    <td class="p-4 font-semibold"><?php echo e($product->stock); ?></td>
                    <td class="p-4"><?php echo e($product->purchased); ?></td>
                    <td class="p-4"><?php echo e($product->sold); ?></td>
                    <td class="p-4">
                        <?php if($product->stock <= 0): ?>
                            <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm">
                                Out of Stock
                            </span>
                        <?php elseif($product->stock <= 10): ?>
                            <span class="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                                Low Stock
                            </span>
                        <?php else: ?>
                            <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                                In Stock
                            </span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    @media print {
        .btn-primary, .bg-gray-500 { display: none; }
        .shadow-lg { box-shadow: none; }
        .rounded-lg { border-radius: 0; }
        @page { margin: 1cm; }
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/reports/stock.blade.php ENDPATH**/ ?>