<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Purchase #<?php echo e($purchase->reference_no); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        .info-section h3 {
            margin-bottom: 10px;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f8f9fa;
        }
        .summary {
            width: 300px;
            margin-left: auto;
        }
        .summary div {
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
        }
        .note {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        @media print {
            body { padding: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Zap Store</h1>
        <h2>Purchase Order</h2>
    </div>

    <div class="info-grid">
        <div class="info-section">
            <h3>Purchase Information</h3>
            <p><strong>Reference No:</strong> <?php echo e($purchase->reference_no); ?></p>
            <p><strong>Date:</strong> <?php echo e($purchase->created_at->format('d M Y h:i A')); ?></p>
            <p><strong>Status:</strong> <?php echo e(ucfirst($purchase->payment_status)); ?></p>
            <p><strong>Payment Method:</strong> <?php echo e(ucfirst($purchase->payment_method)); ?></p>
        </div>
        <div class="info-section">
            <h3>Supplier Information</h3>
            <p><strong>Name:</strong> <?php echo e($purchase->supplier->name); ?></p>
            <p><strong>Phone:</strong> <?php echo e($purchase->supplier->phone); ?></p>
            <p><strong>Email:</strong> <?php echo e($purchase->supplier->email ?? 'N/A'); ?></p>
            <p><strong>Tax Number:</strong> <?php echo e($purchase->supplier->tax_number ?? 'N/A'); ?></p>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->product->name); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td>₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                <td>₹<?php echo e(number_format($item->total_price, 2)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="summary">
        <div>
            <strong>Total Amount:</strong>
            <span>₹<?php echo e(number_format($purchase->total_amount, 2)); ?></span>
        </div>
        <div>
            <strong>Paid Amount:</strong>
            <span>₹<?php echo e(number_format($purchase->paid_amount, 2)); ?></span>
        </div>
        <div>
            <strong>Balance:</strong>
            <span>₹<?php echo e(number_format($purchase->total_amount - $purchase->paid_amount, 2)); ?></span>
        </div>
    </div>

    <?php if($purchase->note): ?>
    <div class="note">
        <h3>Note</h3>
        <p><?php echo e($purchase->note); ?></p>
    </div>
    <?php endif; ?>

    <button class="no-print" onclick="window.print()">Print</button>
</body>
</html> <?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/purchases/print.blade.php ENDPATH**/ ?>