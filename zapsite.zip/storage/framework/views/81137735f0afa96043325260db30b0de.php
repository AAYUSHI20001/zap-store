

<?php $__env->startSection('title', 'Purchases - Zap Store'); ?>
<?php $__env->startSection('header', 'Purchases'); ?>

<?php $__env->startSection('header-buttons'); ?>
<a href="<?php echo e(route('purchases.create')); ?>" class="btn-primary text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
    <i class="fa fa-plus-circle"></i> New Purchase
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-lg rounded-lg p-6">
    <!-- Search and Filter Section -->
    <div class="mb-6 flex justify-between items-center">
        <div class="flex-1 max-w-md">
            <div class="relative">
                <input type="text" 
                       placeholder="Search by reference..." 
                       class="w-full pl-10 pr-4 py-3 text-gray-700 bg-gray-50 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                <span class="absolute left-3 top-3 text-gray-400">
                    <i class="fa fa-search"></i>
                </span>
            </div>
        </div>
        <div class="flex space-x-4">
            <select class="px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                <option value="">All Payment Status</option>
                <option value="paid">Paid</option>
                <option value="partial">Partial</option>
                <option value="pending">Pending</option>
            </select>
            <button class="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600">
                <i class="fa fa-filter mr-2"></i> Filter
            </button>
        </div>
    </div>

    <!-- Purchases Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left border-separate border-spacing-y-2">
            <thead>
                <tr class="bg-gray-100">
                    <th class="p-4 rounded-l-lg">Reference</th>
                    <th class="p-4">Date</th>
                    <th class="p-4">Supplier</th>
                    <th class="p-4">Items</th>
                    <th class="p-4">Total Amount</th>
                    <th class="p-4">Paid Amount</th>
                    <th class="p-4">Status</th>
                    <th class="p-4 rounded-r-lg text-right">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="bg-white hover:bg-gray-50 border-b">
                    <td class="p-4 font-medium"><?php echo e($purchase->reference_no); ?></td>
                    <td class="p-4"><?php echo e($purchase->created_at->format('d M Y')); ?></td>
                    <td class="p-4"><?php echo e($purchase->supplier->name); ?></td>
                    <td class="p-4">
                        <div class="flex flex-col">
                            <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="text-sm">
                                    <?php echo e($item->product->name); ?> × <?php echo e($item->quantity); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </td>
                    <td class="p-4 font-semibold">₹<?php echo e(number_format($purchase->total_amount, 2)); ?></td>
                    <td class="p-4">₹<?php echo e(number_format($purchase->paid_amount, 2)); ?></td>
                    <td class="p-4">
                        <span class="px-3 py-1 rounded-full text-sm
                            <?php if($purchase->payment_status == 'paid'): ?> 
                                bg-green-100 text-green-800
                            <?php elseif($purchase->payment_status == 'partial'): ?>
                                bg-yellow-100 text-yellow-800
                            <?php else: ?>
                                bg-red-100 text-red-800
                            <?php endif; ?>">
                            <?php echo e(ucfirst($purchase->payment_status)); ?>

                        </span>
                    </td>
                    <td class="p-4 text-right">
                        <div class="flex justify-end space-x-2">
                            <a href="<?php echo e(route('purchases.show', $purchase)); ?>" 
                               class="bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600 transition-colors">
                                <i class="fa fa-eye"></i>
                            </a>
                            <button onclick="printPurchase(<?php echo e($purchase->id); ?>)"
                                    class="bg-gray-500 text-white px-3 py-2 rounded-lg hover:bg-gray-600 transition-colors">
                                <i class="fa fa-print"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center py-8 text-gray-500">
                        <i class="fa fa-shopping-cart text-4xl mb-4"></i>
                        <div>No purchases found</div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        <?php echo e($purchases->links()); ?>

    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function printPurchase(id) {
    window.open(`/purchases/${id}/print`, '_blank');
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/purchases/index.blade.php ENDPATH**/ ?>