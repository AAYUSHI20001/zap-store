

<?php $__env->startSection('title', 'Edit Product - Zap Store'); ?>
<?php $__env->startSection('header', 'Edit Product'); ?>

<?php $__env->startSection('header-buttons'); ?>
<a href="<?php echo e(route('products.index')); ?>" class="btn-primary text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
    <i class="fas fa-arrow-left"></i> Back to Products
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-8">
    <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="grid grid-cols-3 gap-8">
            <!-- Left Column - Image Upload -->
            <div class="col-span-1">
                <div class="bg-white p-8 shadow-lg rounded-lg">
                    <h3 class="text-xl font-semibold mb-6 text-gray-700">
                        <i class="fas fa-image mr-2"></i>Product Image
                    </h3>
                    <div class="border-2 border-dashed border-gray-300 p-6 text-center rounded-lg hover:border-blue-500 transition-colors">
                        <img id="preview" 
                             src="<?php echo e($product->image ? asset('storage/products/'.$product->image) : 'https://via.placeholder.com/400x400?text=Upload+Image'); ?>" 
                             alt="Preview" 
                             class="mx-auto mb-6 rounded-lg w-full h-80 object-cover">
                        <input type="file" name="image" id="image" class="hidden" accept="image/*" onchange="previewImage(this)">
                        <button type="button" 
                                onclick="document.getElementById('image').click();" 
                                class="bg-blue-500 text-white px-8 py-4 rounded-lg hover:bg-blue-600 transition-colors w-full flex items-center justify-center text-lg">
                            <i class="fas fa-upload mr-2"></i> Change Image
                        </button>
                        <p class="text-sm text-gray-500 mt-4">
                            Supported formats: JPG, PNG, GIF (Max size: 2MB)
                        </p>
                    </div>
                </div>
            </div>

            <!-- Right Column - Product Information -->
            <div class="col-span-2">
                <div class="bg-white p-8 shadow-lg rounded-lg">
                    <h3 class="text-xl font-semibold mb-8 text-gray-700 border-b pb-4">
                        <i class="fas fa-box mr-2"></i>Product Information
                    </h3>

                    <div class="grid grid-cols-2 gap-8">
                        <!-- Basic Information -->
                        <div class="col-span-2">
                            <label class="block text-gray-700 text-lg mb-3">Product Name <span class="text-red-500">*</span></label>
                            <input type="text" name="name" value="<?php echo e(old('name', $product->name)); ?>" 
                                   class="w-full p-4 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   placeholder="Enter product name"
                                   required>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-gray-700 text-lg mb-3">Product Code/SKU <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <span class="absolute left-4 top-4 text-gray-400 text-xl">
                                    <i class="fas fa-barcode"></i>
                                </span>
                                <input type="text" name="code" value="<?php echo e(old('code', $product->code)); ?>" 
                                       class="w-full p-4 pl-12 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       placeholder="Enter product code"
                                       required>
                            </div>
                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-gray-700 text-lg mb-3">Category</label>
                            <select name="category" class="w-full p-4 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
                                <option value="">Select Category</option>
                                <option value="electronics" <?php echo e(old('category', $product->category) == 'electronics' ? 'selected' : ''); ?>>Electronics</option>
                                <option value="clothing" <?php echo e(old('category', $product->category) == 'clothing' ? 'selected' : ''); ?>>Clothing</option>
                                <option value="food" <?php echo e(old('category', $product->category) == 'food' ? 'selected' : ''); ?>>Food & Beverages</option>
                            </select>
                        </div>

                        <!-- Pricing Information -->
                        <div class="col-span-2">
                            <h4 class="text-lg font-semibold text-gray-700 mb-6 mt-4 border-b pb-4">
                                <i class="fas fa-tag mr-2"></i>Pricing Details
                            </h4>
                        </div>

                        <div>
                            <label class="block text-gray-700 text-lg mb-3">Purchase Price <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <span class="absolute left-4 top-4 text-gray-400 text-xl">₹</span>
                                <input type="number" 
                                       name="purchase_price" 
                                       value="<?php echo e(old('purchase_price', $product->purchase_price)); ?>" 
                                       step="0.01" 
                                       class="w-full p-4 pl-10 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       placeholder="0.00"
                                       required>
                            </div>
                            <?php $__errorArgs = ['purchase_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-gray-700 text-lg mb-3">Selling Price <span class="text-red-500">*</span></label>
                            <div class="relative">
                                <span class="absolute left-4 top-4 text-gray-400 text-xl">₹</span>
                                <input type="number" 
                                       name="selling_price" 
                                       value="<?php echo e(old('selling_price', $product->selling_price)); ?>" 
                                       step="0.01" 
                                       class="w-full p-4 pl-10 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 <?php $__errorArgs = ['selling_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                       placeholder="0.00"
                                       required>
                            </div>
                            <?php $__errorArgs = ['selling_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Inventory Information -->
                        <div class="col-span-2">
                            <h4 class="text-lg font-semibold text-gray-700 mb-6 mt-4 border-b pb-4">
                                <i class="fas fa-warehouse mr-2"></i>Inventory Information
                            </h4>
                        </div>

                        <div>
                            <label class="block text-gray-700 text-lg mb-3">Stock Quantity <span class="text-red-500">*</span></label>
                            <input type="number" name="stock" value="<?php echo e(old('stock', $product->stock)); ?>" 
                                   class="w-full p-4 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   placeholder="Enter quantity"
                                   required>
                            <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block text-gray-700 text-lg mb-3">Alert Quantity</label>
                            <input type="number" name="alert_quantity" value="<?php echo e(old('alert_quantity', $product->alert_quantity)); ?>" 
                                   class="w-full p-4 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500" 
                                   placeholder="Low stock alert quantity">
                        </div>

                        <div class="col-span-2">
                            <label class="block text-gray-700 text-lg mb-3">Product Description</label>
                            <textarea name="description" rows="4" 
                                      class="w-full p-4 text-lg border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                                      placeholder="Enter product description"><?php echo e(old('description', $product->description)); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="mt-8 flex justify-end space-x-6">
                    <button type="button" onclick="window.history.back()" 
                            class="bg-gray-500 text-white px-8 py-4 rounded-lg shadow hover:bg-gray-600 transition-colors flex items-center text-lg">
                        <i class="fas fa-times mr-2"></i> Cancel
                    </button>
                    <button type="submit" 
                            class="bg-blue-500 text-white px-10 py-4 rounded-lg shadow hover:bg-blue-600 transition-colors flex items-center text-lg">
                        <i class="fas fa-save mr-2"></i> Update Product
                    </button>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function previewImage(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('preview').src = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
}

// Add price validation
document.querySelector('form').addEventListener('submit', function(e) {
    const purchasePrice = parseFloat(document.querySelector('[name="purchase_price"]').value);
    const sellingPrice = parseFloat(document.querySelector('[name="selling_price"]').value);
    
    if (sellingPrice < purchasePrice) {
        e.preventDefault();
        alert('Selling price cannot be less than purchase price');
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/products/edit.blade.php ENDPATH**/ ?>