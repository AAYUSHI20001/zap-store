

<?php $__env->startSection('title', 'Users - Zap Store'); ?>
<?php $__env->startSection('header', 'Users'); ?>

<?php $__env->startSection('header-buttons'); ?>
<a href="<?php echo e(route('users.create')); ?>" class="btn-primary text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
    <i class="fa fa-plus-circle"></i> Add User
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-lg rounded-lg p-6">
    <!-- Search -->
    <div class="mb-6">
        <div class="relative max-w-md">
            <input type="text" 
                   placeholder="Search users..." 
                   class="w-full pl-10 pr-4 py-3 text-gray-700 bg-gray-50 border border-gray-300 rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500">
            <span class="absolute left-3 top-3 text-gray-400">
                <i class="fa fa-search"></i>
            </span>
        </div>
    </div>

    <!-- Users Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-50">
                <tr>
                    <th class="p-4">Name</th>
                    <th class="p-4">Email</th>
                    <th class="p-4">Role</th>
                    <th class="p-4">Status</th>
                    <th class="p-4">Created At</th>
                    <th class="p-4 text-right">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="p-4">
                        <div class="flex items-center">
                            <span class="w-8 h-8 rounded-full bg-blue-500 text-white flex items-center justify-center mr-3">
                                <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                            </span>
                            <?php echo e($user->name); ?>

                        </div>
                    </td>
                    <td class="p-4"><?php echo e($user->email); ?></td>
                    <td class="p-4">
                        <span class="px-3 py-1 rounded-full text-sm
                            <?php echo e($user->role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'); ?>">
                            <?php echo e(ucfirst($user->role)); ?>

                        </span>
                    </td>
                    <td class="p-4">
                        <span class="px-3 py-1 rounded-full text-sm
                            <?php echo e($user->status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'); ?>">
                            <?php echo e(ucfirst($user->status)); ?>

                        </span>
                    </td>
                    <td class="p-4"><?php echo e($user->created_at->format('d M Y')); ?></td>
                    <td class="p-4 text-right">
                        <div class="flex justify-end space-x-2">
                            <a href="<?php echo e(route('users.edit', $user)); ?>" 
                               class="bg-blue-500 text-white px-3 py-2 rounded-lg hover:bg-blue-600 transition-colors">
                                <i class="fa fa-edit"></i>
                            </a>
                            <?php if($user->id !== auth()->id()): ?>
                            <form action="<?php echo e(route('users.destroy', $user)); ?>" 
                                  method="POST" 
                                  class="inline-block"
                                  onsubmit="return confirm('Are you sure you want to delete this user?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" 
                                        class="bg-red-500 text-white px-3 py-2 rounded-lg hover:bg-red-600 transition-colors">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center py-8 text-gray-500">
                        <i class="fa fa-users text-4xl mb-4"></i>
                        <div>No users found</div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-6">
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/users/index.blade.php ENDPATH**/ ?>