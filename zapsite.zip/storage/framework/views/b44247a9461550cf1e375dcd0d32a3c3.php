

<?php $__env->startSection('title', 'Stock Value Report - Zap Store'); ?>
<?php $__env->startSection('header', 'Stock Value Report'); ?>

<?php $__env->startSection('header-buttons'); ?>
<div class="flex space-x-4">
    <button onclick="window.print()" class="btn-primary text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
        <i class="fa fa-print"></i> Print Report
    </button>
    <a href="<?php echo e(route('reports.index')); ?>" class="bg-gray-500 text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
        <i class="fa fa-arrow-left"></i> Back to Reports
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-lg rounded-lg p-6">
    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div class="bg-green-50 p-4 rounded-lg">
            <h3 class="text-lg font-semibold text-green-700">Total Stock Value</h3>
            <p class="text-3xl font-bold text-green-800">₹<?php echo e(number_format($totalValue, 2)); ?></p>
        </div>
        <div class="bg-yellow-50 p-4 rounded-lg">
            <h3 class="text-lg font-semibold text-yellow-700">Low Stock Items</h3>
            <p class="text-3xl font-bold text-yellow-800"><?php echo e($lowStock); ?></p>
        </div>
        <div class="bg-red-50 p-4 rounded-lg">
            <h3 class="text-lg font-semibold text-red-700">Out of Stock</h3>
            <p class="text-3xl font-bold text-red-800"><?php echo e($outOfStock); ?></p>
        </div>
    </div>

    <!-- Stock Value Table -->
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead class="bg-gray-50">
                <tr>
                    <th class="p-4">Product</th>
                    <th class="p-4">Code</th>
                    <th class="p-4">Current Stock</th>
                    <th class="p-4">Purchase Price</th>
                    <th class="p-4">Total Value</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="p-4">
                        <div class="flex items-center">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" 
                                     alt="<?php echo e($product->name); ?>"
                                     class="w-10 h-10 rounded-lg object-cover mr-3">
                            <?php endif; ?>
                            <?php echo e($product->name); ?>

                        </div>
                    </td>
                    <td class="p-4"><?php echo e($product->code); ?></td>
                    <td class="p-4 font-semibold"><?php echo e($product->stock); ?></td>
                    <td class="p-4">₹<?php echo e(number_format($product->purchase_price, 2)); ?></td>
                    <td class="p-4 font-semibold">₹<?php echo e(number_format($product->value, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    @media print {
        .btn-primary, .bg-gray-500 { display: none; }
        .shadow-lg { box-shadow: none; }
        .rounded-lg { border-radius: 0; }
        @page { margin: 1cm; }
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/reports/stock-value.blade.php ENDPATH**/ ?>