<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Zap Store - POS'); ?></title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <style>
        .gradient-header {
            background: linear-gradient(135deg, #007bff, #6610f2);
        }
        .nav-item {
            @apply px-4 py-2 text-white hover:bg-blue-700 rounded transition-colors;
        }
        .nav-item.active {
            @apply bg-blue-700;
        }
        .nav-item i {
            @apply mr-2;
        }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="bg-gray-100">
    <!-- Main Navigation -->
    <nav class="bg-gradient-to-r from-blue-500 to-indigo-600 shadow-md">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center py-4">
                <!-- Logo -->
                <div class="text-white font-bold text-2xl">
                    Zap Store
                </div>
    
                <!-- Navigation Items -->   
                <div class="hidden md:flex items-center space-x-4">
                    <a href="<?php echo e(route('dashboard')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('dashboard') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-dashboard"></i> Dashboard
                    </a>
    
                    <a href="<?php echo e(route('products.index')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('products.*') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-box"></i> Products
                    </a>
    
                    <a href="<?php echo e(route('suppliers.index')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('suppliers.*') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-truck"></i> Suppliers
                    </a>
    
                    <a href="<?php echo e(route('pos')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('pos') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-calculator"></i> POS
                    </a>
    
                    <a href="<?php echo e(route('sales.index')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('sales.*') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-shopping-cart"></i> Sales
                    </a>
    
                    <a href="<?php echo e(route('purchases.index')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('purchases.*') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-shopping-bag"></i> Purchases
                    </a>
    
                    <a href="<?php echo e(route('reports.index')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('reports.*') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-chart-bar"></i> Reports
                    </a>
    
                    <a href="<?php echo e(route('users.index')); ?>" 
                       class="   px-4 py-2 rounded-lg transition duration-300 ease-in-out hover:bg-blue-700 <?php echo e(request()->routeIs('users.*') ? 'bg-white text-blue-500 font-bold shadow-lg p-3 rounded-lg' : ''); ?>">
                        <i class="fa fa-users"></i> Users
                    </a>
    
                        
                    <!-- Logout Button -->
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="    hover:bg-red-600 px-4 py-2 rounded-lg text-white">
                            <i class="fa fa-sign-out"></i> Logout
                        </button>
                    </form>
                </div>
    
                <!-- Mobile Menu Button -->
                <button class="md:hidden text-white focus:outline-none">
                    <i class="fa fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
    </nav>
    
    

    <!-- Page Header -->
    <header class="bg-white shadow">
        <div class="container mx-auto py-4 px-6">
            <div class="flex justify-between items-center">
                <h1 class="text-2xl font-bold text-gray-800"><?php echo $__env->yieldContent('header', 'Dashboard'); ?></h1>
                <div>
                    <?php echo $__env->yieldContent('header-buttons'); ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="container mx-auto py-6 px-6">
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html> <?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/layouts/app.blade.php ENDPATH**/ ?>