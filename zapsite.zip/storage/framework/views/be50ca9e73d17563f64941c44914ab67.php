

<?php $__env->startSection('title', 'New Purchase - Zap Store'); ?>
<?php $__env->startSection('header', 'Create New Purchase'); ?>

<?php $__env->startSection('header-buttons'); ?>
<a href="<?php echo e(route('purchases.index')); ?>" class="btn-primary text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
    <i class="fa fa-arrow-left"></i> Back to Purchases
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-lg rounded-lg p-6">
    <form action="<?php echo e(route('purchases.store')); ?>" method="POST" id="purchase-form">
        <?php echo csrf_field(); ?>
        <!-- Hidden Fields -->
        <input type="hidden" name="total_amount" id="total-amount-input">
        
        <div class="grid grid-cols-3 gap-6">
            <!-- Left Column -->
            <div class="col-span-2 space-y-6">
                <!-- Supplier Selection -->
                <div>
                    <label class="block text-gray-700 text-lg mb-2">Select Supplier <span class="text-red-500">*</span></label>
                    <select name="supplier_id" 
                            class="w-full p-3 border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500 <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            required>
                        <option value="">Select a supplier</option>
                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>" <?php echo e(old('supplier_id') == $supplier->id ? 'selected' : ''); ?>>
                                <?php echo e($supplier->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Product Search -->
                <div>
                    <label class="block text-gray-700 text-lg mb-2">Add Products</label>
                    <div class="relative">
                        <input type="text" 
                               id="product-search" 
                               class="w-full p-3 pl-10 border rounded-lg focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                               placeholder="Search products...">
                        <span class="absolute left-3 top-3 text-gray-400">
                            <i class="fa fa-search"></i>
                        </span>
                    </div>
                    <div id="product-list" class="mt-2 max-h-48 overflow-y-auto hidden border rounded-lg">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="p-2 hover:bg-gray-100 cursor-pointer"
                                 onclick="addToCart(<?php echo e(json_encode([
                                     'id' => $product->id,
                                     'name' => $product->name,
                                     'purchase_price' => $product->purchase_price
                                 ])); ?>)">
                                <?php echo e($product->name); ?> - ₹<?php echo e(number_format($product->purchase_price, 2)); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Selected Products Table -->
                <div class="border rounded-lg overflow-hidden">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="p-4">Product</th>
                                <th class="p-4">Quantity</th>
                                <th class="p-4">Unit Price</th>
                                <th class="p-4">Total</th>
                                <th class="p-4"></th>
                            </tr>
                        </thead>
                        <tbody id="cart-items">
                            <!-- Cart items will be added here -->
                        </tbody>
                    </table>
                </div>
                <?php $__errorArgs = ['items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- Right Column - Summary -->
            <div class="space-y-6">
                <div class="border rounded-lg p-4">
                    <h3 class="text-lg font-semibold mb-4">Purchase Summary</h3>
                    
                    <div class="space-y-4">
                        <div class="flex justify-between">
                            <span>Total Amount:</span>
                            <span id="total-amount" class="font-semibold">₹0.00</span>
                        </div>

                        <div>
                            <label class="block mb-2">Payment Method <span class="text-red-500">*</span></label>
                            <select name="payment_method" 
                                    class="w-full p-3 border rounded-lg <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    required>
                                <option value="cash" <?php echo e(old('payment_method') == 'cash' ? 'selected' : ''); ?>>Cash</option>
                                <option value="bank" <?php echo e(old('payment_method') == 'bank' ? 'selected' : ''); ?>>Bank Transfer</option>
                                <option value="upi" <?php echo e(old('payment_method') == 'upi' ? 'selected' : ''); ?>>UPI</option>
                            </select>
                            <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block mb-2">Paid Amount <span class="text-red-500">*</span></label>
                            <input type="number" 
                                   name="paid_amount" 
                                   value="<?php echo e(old('paid_amount', 0)); ?>"
                                   class="w-full p-3 border rounded-lg <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   step="0.01"
                                   min="0"
                                   required>
                            <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div>
                            <label class="block mb-2">Note</label>
                            <textarea name="note" 
                                      rows="3" 
                                      class="w-full p-3 border rounded-lg"><?php echo e(old('note')); ?></textarea>
                        </div>
                    </div>
                </div>

                <button type="submit" 
                        class="w-full bg-blue-500 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-600 transition-colors">
                    <i class="fa fa-save mr-2"></i>Save Purchase
                </button>
            </div>
        </div>
    </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
let cart = [];

// Product search functionality
document.getElementById('product-search').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const productList = document.getElementById('product-list');
    
    if (searchTerm.length > 0) {
        productList.classList.remove('hidden');
        Array.from(productList.children).forEach(product => {
            const productName = product.textContent.toLowerCase();
            product.style.display = productName.includes(searchTerm) ? 'block' : 'none';
        });
    } else {
        productList.classList.add('hidden');
    }
});

// Add to cart function
function addToCart(product) {
    const existingItem = cart.find(item => item.product_id === product.id);
    
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            product_id: product.id,
            name: product.name,
            quantity: 1,
            unit_price: product.purchase_price
        });
    }
    
    updateCartDisplay();
    document.getElementById('product-search').value = '';
    document.getElementById('product-list').classList.add('hidden');
}

// Update quantity
function updateQuantity(index, change) {
    const newQuantity = cart[index].quantity + change;
    if (newQuantity > 0) {
        cart[index].quantity = newQuantity;
        updateCartDisplay();
    }
}

// Remove from cart
function removeFromCart(index) {
    cart.splice(index, 1);
    updateCartDisplay();
}

// Update cart display
function updateCartDisplay() {
    const cartDiv = document.getElementById('cart-items');
    cartDiv.innerHTML = '';
    
    cart.forEach((item, index) => {
        const total = item.quantity * item.unit_price;
        cartDiv.innerHTML += `
            <tr class="border-t">
                <td class="p-4">${item.name}</td>
                <td class="p-4">
                    <div class="flex items-center space-x-2">
                        <button type="button" onclick="updateQuantity(${index}, -1)" 
                                class="px-2 py-1 bg-gray-200 rounded hover:bg-gray-300">-</button>
                        <span>${item.quantity}</span>
                        <button type="button" onclick="updateQuantity(${index}, 1)" 
                                class="px-2 py-1 bg-gray-200 rounded hover:bg-gray-300">+</button>
                    </div>
                </td>
                <td class="p-4">₹${item.unit_price}</td>
                <td class="p-4">₹${total.toFixed(2)}</td>
                <td class="p-4">
                    <button type="button" onclick="removeFromCart(${index})" 
                            class="text-red-500 hover:text-red-600">
                        <i class="fa fa-trash"></i>
                    </button>
                </td>
            </tr>
        `;
    });
    
    updateTotal();
}

// Update total
function updateTotal() {
    const total = cart.reduce((sum, item) => sum + (item.unit_price * item.quantity), 0);
    document.getElementById('total-amount').textContent = `₹${total.toFixed(2)}`;
    document.getElementById('total-amount-input').value = total;
}

// Form submission
document.getElementById('purchase-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (cart.length === 0) {
        alert('Please add at least one product to the purchase.');
        return;
    }
    
    // Create an array of items with the correct format
    cart.forEach((item, index) => {
        const itemInput = document.createElement('input');
        itemInput.type = 'hidden';
        itemInput.name = `items[${index}][product_id]`;
        itemInput.value = item.product_id;
        this.appendChild(itemInput);

        const quantityInput = document.createElement('input');
        quantityInput.type = 'hidden';
        quantityInput.name = `items[${index}][quantity]`;
        quantityInput.value = item.quantity;
        this.appendChild(quantityInput);

        const priceInput = document.createElement('input');
        priceInput.type = 'hidden';
        priceInput.name = `items[${index}][unit_price]`;
        priceInput.value = item.unit_price;
        this.appendChild(priceInput);
    });
    
    this.submit();
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/purchases/create.blade.php ENDPATH**/ ?>