

<?php $__env->startSection('title', 'Purchase Details - Zap Store'); ?>
<?php $__env->startSection('header', 'Purchase Details'); ?>

<?php $__env->startSection('header-buttons'); ?>
<div class="flex space-x-4">
    <a href="<?php echo e(route('purchases.index')); ?>" class="btn-primary text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
        <i class="fa fa-arrow-left"></i> Back to Purchases
    </a>
    <button onclick="window.print()" class="bg-gray-500 text-white px-6 py-3 rounded-lg shadow hover:scale-105 transition text-lg">
        <i class="fa fa-print"></i> Print
    </button>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-lg rounded-lg p-6">
    <!-- Purchase Header -->
    <div class="grid grid-cols-2 gap-6 mb-6">
        <div>
            <h3 class="text-lg font-semibold text-gray-700 mb-4">Purchase Information</h3>
            <div class="space-y-2">
                <p><span class="font-medium">Reference No:</span> <?php echo e($purchase->reference_no); ?></p>
                <p><span class="font-medium">Date:</span> <?php echo e($purchase->created_at->format('d M Y h:i A')); ?></p>
                <p><span class="font-medium">Status:</span> 
                    <span class="px-3 py-1 rounded-full text-sm
                        <?php if($purchase->payment_status == 'paid'): ?> 
                            bg-green-100 text-green-800
                        <?php elseif($purchase->payment_status == 'partial'): ?>
                            bg-yellow-100 text-yellow-800
                        <?php else: ?>
                            bg-red-100 text-red-800
                        <?php endif; ?>">
                        <?php echo e(ucfirst($purchase->payment_status)); ?>

                    </span>
                </p>
                <p><span class="font-medium">Payment Method:</span> <?php echo e(ucfirst($purchase->payment_method)); ?></p>
            </div>
        </div>
        <div>
            <h3 class="text-lg font-semibold text-gray-700 mb-4">Supplier Information</h3>
            <div class="space-y-2">
                <p><span class="font-medium">Name:</span> <?php echo e($purchase->supplier->name); ?></p>
                <p><span class="font-medium">Phone:</span> <?php echo e($purchase->supplier->phone); ?></p>
                <p><span class="font-medium">Email:</span> <?php echo e($purchase->supplier->email ?? 'N/A'); ?></p>
                <p><span class="font-medium">Tax Number:</span> <?php echo e($purchase->supplier->tax_number ?? 'N/A'); ?></p>
            </div>
        </div>
    </div>

    <!-- Purchase Items -->
    <div class="mb-6">
        <h3 class="text-lg font-semibold text-gray-700 mb-4">Purchase Items</h3>
        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="p-4 rounded-l-lg">Product</th>
                        <th class="p-4">Quantity</th>
                        <th class="p-4">Unit Price</th>
                        <th class="p-4 rounded-r-lg">Total</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="p-4"><?php echo e($item->product->name); ?></td>
                        <td class="p-4"><?php echo e($item->quantity); ?></td>
                        <td class="p-4">₹<?php echo e(number_format($item->unit_price, 2)); ?></td>
                        <td class="p-4">₹<?php echo e(number_format($item->total_price, 2)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Purchase Summary -->
    <div class="border-t pt-6">
        <div class="w-1/3 ml-auto space-y-3">
            <div class="flex justify-between">
                <span class="font-medium">Total Amount:</span>
                <span>₹<?php echo e(number_format($purchase->total_amount, 2)); ?></span>
            </div>
            <div class="flex justify-between">
                <span class="font-medium">Paid Amount:</span>
                <span>₹<?php echo e(number_format($purchase->paid_amount, 2)); ?></span>
            </div>
            <div class="flex justify-between text-red-600">
                <span class="font-medium">Balance:</span>
                <span>₹<?php echo e(number_format($purchase->total_amount - $purchase->paid_amount, 2)); ?></span>
            </div>
        </div>
    </div>

    <?php if($purchase->note): ?>
    <div class="mt-6 border-t pt-6">
        <h3 class="text-lg font-semibold text-gray-700 mb-2">Note</h3>
        <p class="text-gray-600"><?php echo e($purchase->note); ?></p>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    @media print {
        .btn-primary, .bg-gray-500 { display: none; }
        .shadow-lg { box-shadow: none; }
        .rounded-lg { border-radius: 0; }
        @page { margin: 1cm; }
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\wamp64\www\zap-store\resources\views/purchases/show.blade.php ENDPATH**/ ?>